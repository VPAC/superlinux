#include <mpi.h>
#include <stdio.h>
#include <math.h>

#define WORKTAG 1
#define DIETAG 2

#define MAXNUM 1000000000

static void master();
static void slave(int myrank);

/*
* main
* This program is really MIMD, but is written SPMD for
* simplicity in launching the application.
*/
int main(int argc, char *argv[]) {

	int myrank;
	char name[100];
	int len;

	MPI_Init(&argc, &argv);

	MPI_Comm_rank(MPI_COMM_WORLD, /* group of everybody */
		&myrank); /* 0 thru N-1 */

	MPI_Get_processor_name(name, &len);

	printf("\t\t\t\t\tHello. I am n%i, running on %s.\n",myrank,name);

	if (myrank == 0) {
		master();
	} else {
		slave(myrank);
	}
	MPI_Finalize();
	return(0);
}

/*
* master
* The master process sends work requests to the slaves
* and collects results.
*/

static void master()
{
	int ntasks, rank;
	long min,max,jump;
	long range[2];
	double sum;
	double ret;
	double result;
	double time_start, time_stop;
	MPI_Status status;

	MPI_Comm_size(MPI_COMM_WORLD, &ntasks); /* #processes in app */

	if (ntasks < 2) {
		printf("Please run with 2 or more nodes...\n");
		return; 
	}

/*
* Seed the slaves.
*/

	jump = MAXNUM/(ntasks-1);
	
	time_start = MPI_Wtime();
	
	for (rank = 1; rank < ntasks; rank++) {
		
		min=(rank-1)*jump;
		max=rank*jump-1;

		if (rank==ntasks-1)
			max=MAXNUM;
		
		if (rank==1)
			min=0;

		range[0]=min;
		range[1]=max;

		MPI_Send(&range, /* message buffer */
			2, /* two data items */
			MPI_LONG, /* of this type */
			rank, /* to this rank */
			WORKTAG, /* a work message */
			MPI_COMM_WORLD); /* always use this */
		printf("Sent range [%i-%i] to node %i.\n", min,max, rank);
	}

/*
* Receive a result from any slave and dispatch a new work
* request until work requests have been exhausted.
*/
	sum=0;

	for (rank = 1; rank < ntasks; ++rank) {
		MPI_Recv(&ret, 1, MPI_DOUBLE, MPI_ANY_SOURCE,
		MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		sum+=ret;
		printf("got one from node%i: %lf\n",status.MPI_SOURCE, ret);
	}

	time_stop=MPI_Wtime();

        printf("Total time: %f\n",time_stop-time_start);

	printf("\nSum is: %lf\n\n",sum);
/*
* Tell all the slaves to exit.
*/

	for (rank = 1; rank < ntasks; ++rank) {
		MPI_Send(0, 0, MPI_INT, rank, DIETAG,
		MPI_COMM_WORLD);
	}
}

/*
* slave
* Each slave process accepts work requests and returns
* results until a special termination request is received.
*/
static void slave(int myrank) {

	double result;
	long range[2];
	long min,max;
	MPI_Status status;
	double i;
	char* indent="";

	for (;;) {
		MPI_Recv(&range, 2, MPI_LONG, 0, MPI_ANY_TAG,
			MPI_COMM_WORLD, &status);
/*
* Check the tag of the received message.
*/

	if (status.MPI_TAG == DIETAG) {
		return;
	}

	min=range[0];
	max=range[1];

	if (myrank==2)
		indent="\t\t\t";

	result=0;
	for (i=min;i<=max;i++) {
		result+=sqrt(i);

/*		if (i%1000000==0)
			printf("%snode %i: doing %i...\n",indent,myrank,i);
*/		
	}
	
	MPI_Send(&result, 1, MPI_DOUBLE, 0, 0,
		MPI_COMM_WORLD);
}
}
